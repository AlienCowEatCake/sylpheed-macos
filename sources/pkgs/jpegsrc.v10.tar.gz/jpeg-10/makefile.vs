# Makefile for Independent JPEG Group's software

# This makefile is for Microsoft Visual C++ on Windows 9x or NT.
# It builds the IJG library as a statically linkable library (.LIB),
# and builds the sample applications as console-mode apps.
# Thanks to Xingong Chang, Raymond Everly and others.

# Read installation instructions before saying "nmake" !!
# To build an optimized library without debug info, say "nmake nodebug=1".

# Pull in standard variable definitions
#!include <win32.mak>

# You may want to adjust these compiler options:
CFLAGS= $(cflags) $(cdebug) $(cvars) -I.
# Generally, we recommend defining any configuration symbols in jconfig.h,
# NOT via -D switches here.

# Link-time options:
LDFLAGS= $(ldebug) $(conlflags)

# To link any special libraries, add the necessary commands here.
LDLIBS= $(conlibs)

# Put here the object file name for the correct system-dependent memory
# manager file.  For NT we suggest jmemnobs.obj, which expects the OS to
# provide adequate virtual memory.
SYSDEPMEM= jmemnobs.obj

# miscellaneous OS-dependent stuff
# file deletion command
RM= del

# End of configurable options.


# source files: JPEG library proper
LIBSOURCES= jaricom.c jcapimin.c jcapistd.c jcarith.c jccoefct.c jccolor.c \
        jcdctmgr.c jchuff.c jcinit.c jcmainct.c jcmarker.c jcmaster.c \
        jcomapi.c jcparam.c jcprepct.c jcsample.c jctrans.c jdapimin.c \
        jdapistd.c jdarith.c jdatadst.c jdatasrc.c jdcoefct.c jdcolor.c \
        jddctmgr.c jdhuff.c jdinput.c jdmainct.c jdmarker.c jdmaster.c \
        jdmerge.c jdpostct.c jdsample.c jdtrans.c jerror.c jfdctflt.c \
        jfdctfst.c jfdctint.c jidctflt.c jidctfst.c jidctint.c jquant1.c \
        jquant2.c jutils.c jmemmgr.c
# memmgr back ends: compile only one of these into a working library
SYSDEPSOURCES= jmemansi.c jmemname.c jmemnobs.c jmemdos.c jmemmac.c
# source files: cjpeg/djpeg/jpegtran applications, also rdjpgcom/wrjpgcom
APPSOURCES= cjpeg.c djpeg.c jpegtran.c rdjpgcom.c wrjpgcom.c cdjpeg.c \
        rdcolmap.c rdswitch.c transupp.c rdppm.c wrppm.c rdgif.c wrgif.c \
        rdtarga.c wrtarga.c rdbmp.c wrbmp.c rdrle.c wrrle.c
SOURCES= $(LIBSOURCES) $(SYSDEPSOURCES) $(APPSOURCES)
# files included by source files
INCLUDES= jdct.h jerror.h jinclude.h jmemsys.h jmorecfg.h jpegint.h \
        jpeglib.h jversion.h cdjpeg.h cderror.h transupp.h
# documentation, test, and support files
DOCS= README install.txt usage.txt cjpeg.1 djpeg.1 jpegtran.1 rdjpgcom.1 \
        wrjpgcom.1 wizard.txt example.c libjpeg.txt structure.txt \
        coderules.txt filelist.txt cdaltui.txt change.log
MKFILES= configure Makefile.in makefile.ansi makefile.unix makefile.xc \
        makefile.bcc makefile.b32 makefile.c32 makefile.d32 makefile.x32 \
        makefile.b64 makefile.x64 makefile.mc6 makefile.dj makefile.wat \
        makefile.vc makefile.vs makejdsw.vc6 makeadsw.vc6 makejdep.vc6 \
        makejdsp.vc6 makejmak.vc6 makecdep.vc6 makecdsp.vc6 makecmak.vc6 \
        makeddep.vc6 makeddsp.vc6 makedmak.vc6 maketdep.vc6 maketdsp.vc6 \
        maketmak.vc6 makerdep.vc6 makerdsp.vc6 makermak.vc6 makewdep.vc6 \
        makewdsp.vc6 makewmak.vc6 makejsln.v16 makeasln.v16 makejvcx.v16 \
        makejfil.v16 makecvcx.v16 makecfil.v16 makedvcx.v16 makedfil.v16 \
        maketvcx.v16 maketfil.v16 makervcx.v16 makerfil.v16 makewvcx.v16 \
        makewfil.v16 makajpeg.bcb makcjpeg.bcb makdjpeg.bcb makljpeg.bcb \
        makrjpeg.bcb maktjpeg.bcb makwjpeg.bcb makcjpeg.st makdjpeg.st \
        makljpeg.st maktjpeg.st makeproj.mac makefile.manx makefile.sas \
        makefile.mms makefile.vms makvms.opt
CONFIGFILES= jconfig.cfg jconfig.xc jconfig.bcc jconfig.mc6 jconfig.dj \
        jconfig.wat jconfig.vc jconfig.mac jconfig.st jconfig.manx \
        jconfig.sas jconfig.vms
CONFIGUREFILES= config.guess config.sub install-sh ltmain.sh depcomp \
        missing ar-lib
OTHERFILES= jconfig.txt ckconfig.c jmemdosa.asm libjpeg.map libjpeg.pc.in \
        cjpegalt.c djpegalt.c
TESTFILES= testorig.jpg testimg.ppm testimg.gif testimg.bmp testimg.jpg \
        testprog.jpg testimgp.jpg
DISTFILES= $(DOCS) $(MKFILES) $(CONFIGFILES) $(SOURCES) $(INCLUDES) \
        $(CONFIGUREFILES) $(OTHERFILES) $(TESTFILES)
# library object files common to compression and decompression
COMOBJECTS= jaricom.obj jcomapi.obj jutils.obj jerror.obj jmemmgr.obj $(SYSDEPMEM)
# compression library object files
CLIBOBJECTS= jcapimin.obj jcapistd.obj jcarith.obj jctrans.obj jcparam.obj \
        jdatadst.obj jcinit.obj jcmaster.obj jcmarker.obj jcmainct.obj \
        jcprepct.obj jccoefct.obj jccolor.obj jcsample.obj jchuff.obj \
        jcdctmgr.obj jfdctfst.obj jfdctflt.obj jfdctint.obj
# decompression library object files
DLIBOBJECTS= jdapimin.obj jdapistd.obj jdarith.obj jdtrans.obj jdatasrc.obj \
        jdmaster.obj jdinput.obj jdmarker.obj jdhuff.obj jdmainct.obj \
        jdcoefct.obj jdpostct.obj jddctmgr.obj jidctfst.obj jidctflt.obj \
        jidctint.obj jdsample.obj jdcolor.obj jquant1.obj jquant2.obj \
        jdmerge.obj
# These objectfiles are included in libjpeg.lib
LIBOBJECTS= $(CLIBOBJECTS) $(DLIBOBJECTS) $(COMOBJECTS)
# object files for sample applications (excluding library files)
COBJECTS= cjpeg.obj rdppm.obj rdgif.obj rdtarga.obj rdrle.obj rdbmp.obj \
        rdswitch.obj cdjpeg.obj
DOBJECTS= djpeg.obj wrppm.obj wrgif.obj wrtarga.obj wrrle.obj wrbmp.obj \
        rdcolmap.obj cdjpeg.obj
TROBJECTS= jpegtran.obj rdswitch.obj cdjpeg.obj transupp.obj

# Template command for compiling .c to .obj
.c.obj:
	$(cc) $(CFLAGS) $*.c


all: libjpeg.lib cjpeg.exe djpeg.exe jpegtran.exe rdjpgcom.exe wrjpgcom.exe

libjpeg.lib: $(LIBOBJECTS)
	$(RM) libjpeg.lib
	lib -out:libjpeg.lib  $(LIBOBJECTS)

cjpeg.exe: $(COBJECTS) libjpeg.lib
	$(link) $(LDFLAGS) -out:cjpeg.exe $(COBJECTS) libjpeg.lib $(LDLIBS)

djpeg.exe: $(DOBJECTS) libjpeg.lib
	$(link) $(LDFLAGS) -out:djpeg.exe $(DOBJECTS) libjpeg.lib $(LDLIBS)

jpegtran.exe: $(TROBJECTS) libjpeg.lib
	$(link) $(LDFLAGS) -out:jpegtran.exe $(TROBJECTS) libjpeg.lib $(LDLIBS)

rdjpgcom.exe: rdjpgcom.obj
	$(link) $(LDFLAGS) -out:rdjpgcom.exe rdjpgcom.obj $(LDLIBS)

wrjpgcom.exe: wrjpgcom.obj
	$(link) $(LDFLAGS) -out:wrjpgcom.exe wrjpgcom.obj $(LDLIBS)


clean:
	$(RM) *.obj *.exe libjpeg.lib
	$(RM) testout*

setup-vc6:
	if not exist jconfig.h ren jconfig.vc jconfig.h
	ren makejdsw.vc6 jpeg.dsw
	ren makeadsw.vc6 apps.dsw
	ren makejmak.vc6 jpeg.mak
	ren makejdep.vc6 jpeg.dep
	ren makejdsp.vc6 jpeg.dsp
	ren makecmak.vc6 cjpeg.mak
	ren makecdep.vc6 cjpeg.dep
	ren makecdsp.vc6 cjpeg.dsp
	ren makedmak.vc6 djpeg.mak
	ren makeddep.vc6 djpeg.dep
	ren makeddsp.vc6 djpeg.dsp
	ren maketmak.vc6 jpegtran.mak
	ren maketdep.vc6 jpegtran.dep
	ren maketdsp.vc6 jpegtran.dsp
	ren makermak.vc6 rdjpgcom.mak
	ren makerdep.vc6 rdjpgcom.dep
	ren makerdsp.vc6 rdjpgcom.dsp
	ren makewmak.vc6 wrjpgcom.mak
	ren makewdep.vc6 wrjpgcom.dep
	ren makewdsp.vc6 wrjpgcom.dsp

setupcopy-vc6:
	copy /y jconfig.vc jconfig.h
	copy /y makejdsw.vc6 jpeg.dsw
	copy /y makeadsw.vc6 apps.dsw
	copy /y makejmak.vc6 jpeg.mak
	copy /y makejdep.vc6 jpeg.dep
	copy /y makejdsp.vc6 jpeg.dsp
	copy /y makecmak.vc6 cjpeg.mak
	copy /y makecdep.vc6 cjpeg.dep
	copy /y makecdsp.vc6 cjpeg.dsp
	copy /y makedmak.vc6 djpeg.mak
	copy /y makeddep.vc6 djpeg.dep
	copy /y makeddsp.vc6 djpeg.dsp
	copy /y maketmak.vc6 jpegtran.mak
	copy /y maketdep.vc6 jpegtran.dep
	copy /y maketdsp.vc6 jpegtran.dsp
	copy /y makermak.vc6 rdjpgcom.mak
	copy /y makerdep.vc6 rdjpgcom.dep
	copy /y makerdsp.vc6 rdjpgcom.dsp
	copy /y makewmak.vc6 wrjpgcom.mak
	copy /y makewdep.vc6 wrjpgcom.dep
	copy /y makewdsp.vc6 wrjpgcom.dsp

setup-v16:
	if not exist jconfig.h ren jconfig.vc jconfig.h
	ren makejsln.v16 jpeg.sln
	ren makeasln.v16 apps.sln
	ren makejvcx.v16 jpeg.vcxproj
	ren makejfil.v16 jpeg.vcxproj.filters
	ren makecvcx.v16 cjpeg.vcxproj
	ren makecfil.v16 cjpeg.vcxproj.filters
	ren makedvcx.v16 djpeg.vcxproj
	ren makedfil.v16 djpeg.vcxproj.filters
	ren maketvcx.v16 jpegtran.vcxproj
	ren maketfil.v16 jpegtran.vcxproj.filters
	ren makervcx.v16 rdjpgcom.vcxproj
	ren makerfil.v16 rdjpgcom.vcxproj.filters
	ren makewvcx.v16 wrjpgcom.vcxproj
	ren makewfil.v16 wrjpgcom.vcxproj.filters

setupcopy-v16:
	copy /y jconfig.vc jconfig.h
	copy /y makejsln.v16 jpeg.sln
	copy /y makeasln.v16 apps.sln
	copy /y makejvcx.v16 jpeg.vcxproj
	copy /y makejfil.v16 jpeg.vcxproj.filters
	copy /y makecvcx.v16 cjpeg.vcxproj
	copy /y makecfil.v16 cjpeg.vcxproj.filters
	copy /y makedvcx.v16 djpeg.vcxproj
	copy /y makedfil.v16 djpeg.vcxproj.filters
	copy /y maketvcx.v16 jpegtran.vcxproj
	copy /y maketfil.v16 jpegtran.vcxproj.filters
	copy /y makervcx.v16 rdjpgcom.vcxproj
	copy /y makerfil.v16 rdjpgcom.vcxproj.filters
	copy /y makewvcx.v16 wrjpgcom.vcxproj
	copy /y makewfil.v16 wrjpgcom.vcxproj.filters

test:
	IF EXIST testout* $(RM) testout*
	.\djpeg -dct int -ppm -outfile testout.ppm testorig.jpg
	.\djpeg -dct int -gif -outfile testout.gif testorig.jpg
	.\djpeg -dct int -bmp -colors 256 -outfile testout.bmp testorig.jpg
	.\cjpeg -dct int -outfile testout.jpg testimg.ppm
	.\djpeg -dct int -ppm -outfile testoutp.ppm testprog.jpg
	.\cjpeg -dct int -progressive -opt -outfile testoutp.jpg testimg.ppm
	.\jpegtran -outfile testoutt.jpg testprog.jpg
	fc /b testimg.ppm testout.ppm
	fc /b testimg.gif testout.gif
	fc /b testimg.bmp testout.bmp
	fc /b testimg.jpg testout.jpg
	fc /b testimg.ppm testoutp.ppm
	fc /b testimgp.jpg testoutp.jpg
	fc /b testorig.jpg testoutt.jpg

test-build:
	IF EXIST .\Release\testout* $(RM) .\Release\testout*
	.\Release\djpeg -dct int -ppm -outfile .\Release\testout.ppm testorig.jpg
	.\Release\djpeg -dct int -gif -outfile .\Release\testout.gif testorig.jpg
	.\Release\djpeg -dct int -bmp -colors 256 -outfile .\Release\testout.bmp testorig.jpg
	.\Release\cjpeg -dct int -outfile .\Release\testout.jpg testimg.ppm
	.\Release\djpeg -dct int -ppm -outfile .\Release\testoutp.ppm testprog.jpg
	.\Release\cjpeg -dct int -progressive -opt -outfile .\Release\testoutp.jpg testimg.ppm
	.\Release\jpegtran -outfile .\Release\testoutt.jpg testprog.jpg
	fc /b testimg.ppm .\Release\testout.ppm
	fc /b testimg.gif .\Release\testout.gif
	fc /b testimg.bmp .\Release\testout.bmp
	fc /b testimg.jpg .\Release\testout.jpg
	fc /b testimg.ppm .\Release\testoutp.ppm
	fc /b testimgp.jpg .\Release\testoutp.jpg
	fc /b testorig.jpg .\Release\testoutt.jpg

test-32:
	IF EXIST .\Release\testout* $(RM) .\Release\testout*
	.\Release\Win32\djpeg -dct int -ppm -outfile .\Release\testout.ppm testorig.jpg
	.\Release\Win32\djpeg -dct int -gif -outfile .\Release\testout.gif testorig.jpg
	.\Release\Win32\djpeg -dct int -bmp -colors 256 -outfile .\Release\testout.bmp testorig.jpg
	.\Release\Win32\cjpeg -dct int -outfile .\Release\testout.jpg testimg.ppm
	.\Release\Win32\djpeg -dct int -ppm -outfile .\Release\testoutp.ppm testprog.jpg
	.\Release\Win32\cjpeg -dct int -progressive -opt -outfile .\Release\testoutp.jpg testimg.ppm
	.\Release\Win32\jpegtran -outfile .\Release\testoutt.jpg testprog.jpg
	fc /b testimg.ppm .\Release\testout.ppm
	fc /b testimg.gif .\Release\testout.gif
	fc /b testimg.bmp .\Release\testout.bmp
	fc /b testimg.jpg .\Release\testout.jpg
	fc /b testimg.ppm .\Release\testoutp.ppm
	fc /b testimgp.jpg .\Release\testoutp.jpg
	fc /b testorig.jpg .\Release\testoutt.jpg

test-64:
	IF EXIST .\Release\testout* $(RM) .\Release\testout*
	.\Release\x64\djpeg -dct int -ppm -outfile .\Release\testout.ppm testorig.jpg
	.\Release\x64\djpeg -dct int -gif -outfile .\Release\testout.gif testorig.jpg
	.\Release\x64\djpeg -dct int -bmp -colors 256 -outfile .\Release\testout.bmp testorig.jpg
	.\Release\x64\cjpeg -dct int -outfile .\Release\testout.jpg testimg.ppm
	.\Release\x64\djpeg -dct int -ppm -outfile .\Release\testoutp.ppm testprog.jpg
	.\Release\x64\cjpeg -dct int -progressive -opt -outfile .\Release\testoutp.jpg testimg.ppm
	.\Release\x64\jpegtran -outfile .\Release\testoutt.jpg testprog.jpg
	fc /b testimg.ppm .\Release\testout.ppm
	fc /b testimg.gif .\Release\testout.gif
	fc /b testimg.bmp .\Release\testout.bmp
	fc /b testimg.jpg .\Release\testout.jpg
	fc /b testimg.ppm .\Release\testoutp.ppm
	fc /b testimgp.jpg .\Release\testoutp.jpg
	fc /b testorig.jpg .\Release\testoutt.jpg

test-arm64:
	IF EXIST .\Release\testout* $(RM) .\Release\testout*
	.\Release\ARM64\djpeg -dct int -ppm -outfile .\Release\testout.ppm testorig.jpg
	.\Release\ARM64\djpeg -dct int -gif -outfile .\Release\testout.gif testorig.jpg
	.\Release\ARM64\djpeg -dct int -bmp -colors 256 -outfile .\Release\testout.bmp testorig.jpg
	.\Release\ARM64\cjpeg -dct int -outfile .\Release\testout.jpg testimg.ppm
	.\Release\ARM64\djpeg -dct int -ppm -outfile .\Release\testoutp.ppm testprog.jpg
	.\Release\ARM64\cjpeg -dct int -progressive -opt -outfile .\Release\testoutp.jpg testimg.ppm
	.\Release\ARM64\jpegtran -outfile .\Release\testoutt.jpg testprog.jpg
	fc /b testimg.ppm .\Release\testout.ppm
	fc /b testimg.gif .\Release\testout.gif
	fc /b testimg.bmp .\Release\testout.bmp
	fc /b testimg.jpg .\Release\testout.jpg
	fc /b testimg.ppm .\Release\testoutp.ppm
	fc /b testimgp.jpg .\Release\testoutp.jpg
	fc /b testorig.jpg .\Release\testoutt.jpg

test-arm64ec:
	IF EXIST .\Release\testout* $(RM) .\Release\testout*
	.\Release\ARM64EC\djpeg -dct int -ppm -outfile .\Release\testout.ppm testorig.jpg
	.\Release\ARM64EC\djpeg -dct int -gif -outfile .\Release\testout.gif testorig.jpg
	.\Release\ARM64EC\djpeg -dct int -bmp -colors 256 -outfile .\Release\testout.bmp testorig.jpg
	.\Release\ARM64EC\cjpeg -dct int -outfile .\Release\testout.jpg testimg.ppm
	.\Release\ARM64EC\djpeg -dct int -ppm -outfile .\Release\testoutp.ppm testprog.jpg
	.\Release\ARM64EC\cjpeg -dct int -progressive -opt -outfile .\Release\testoutp.jpg testimg.ppm
	.\Release\ARM64EC\jpegtran -outfile .\Release\testoutt.jpg testprog.jpg
	fc /b testimg.ppm .\Release\testout.ppm
	fc /b testimg.gif .\Release\testout.gif
	fc /b testimg.bmp .\Release\testout.bmp
	fc /b testimg.jpg .\Release\testout.jpg
	fc /b testimg.ppm .\Release\testoutp.ppm
	fc /b testimgp.jpg .\Release\testoutp.jpg
	fc /b testorig.jpg .\Release\testoutt.jpg


jaricom.obj: jaricom.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcapimin.obj: jcapimin.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcapistd.obj: jcapistd.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcarith.obj: jcarith.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jccoefct.obj: jccoefct.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jccolor.obj: jccolor.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcdctmgr.obj: jcdctmgr.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jdct.h
jchuff.obj: jchuff.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcinit.obj: jcinit.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcmainct.obj: jcmainct.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcmarker.obj: jcmarker.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcmaster.obj: jcmaster.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcomapi.obj: jcomapi.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcparam.obj: jcparam.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcprepct.obj: jcprepct.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jcsample.obj: jcsample.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jctrans.obj: jctrans.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdapimin.obj: jdapimin.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdapistd.obj: jdapistd.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdarith.obj: jdarith.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdatadst.obj: jdatadst.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h
jdatasrc.obj: jdatasrc.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h
jdcoefct.obj: jdcoefct.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdcolor.obj: jdcolor.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jddctmgr.obj: jddctmgr.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jdct.h
jdhuff.obj: jdhuff.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdinput.obj: jdinput.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdmainct.obj: jdmainct.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdmarker.obj: jdmarker.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdmaster.obj: jdmaster.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdmerge.obj: jdmerge.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdpostct.obj: jdpostct.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdsample.obj: jdsample.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jdtrans.obj: jdtrans.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jerror.obj: jerror.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jversion.h jerror.h
jfdctflt.obj: jfdctflt.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jdct.h
jfdctfst.obj: jfdctfst.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jdct.h
jfdctint.obj: jfdctint.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jdct.h
jidctflt.obj: jidctflt.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jdct.h
jidctfst.obj: jidctfst.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jdct.h
jidctint.obj: jidctint.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jdct.h
jquant1.obj: jquant1.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jquant2.obj: jquant2.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jutils.obj: jutils.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h
jmemmgr.obj: jmemmgr.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jmemsys.h
jmemansi.obj: jmemansi.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jmemsys.h
jmemname.obj: jmemname.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jmemsys.h
jmemnobs.obj: jmemnobs.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jmemsys.h
jmemdos.obj: jmemdos.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jmemsys.h
jmemmac.obj: jmemmac.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h jmemsys.h
cjpeg.obj: cjpeg.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h jversion.h
djpeg.obj: djpeg.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h jversion.h
jpegtran.obj: jpegtran.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h transupp.h jversion.h
rdjpgcom.obj: rdjpgcom.c jinclude.h jconfig.h
wrjpgcom.obj: wrjpgcom.c jinclude.h jconfig.h
cdjpeg.obj: cdjpeg.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
rdcolmap.obj: rdcolmap.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
rdswitch.obj: rdswitch.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
transupp.obj: transupp.c jinclude.h jconfig.h jpeglib.h jmorecfg.h jpegint.h jerror.h transupp.h
rdppm.obj: rdppm.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
wrppm.obj: wrppm.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
rdgif.obj: rdgif.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
wrgif.obj: wrgif.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
rdtarga.obj: rdtarga.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
wrtarga.obj: wrtarga.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
rdbmp.obj: rdbmp.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
wrbmp.obj: wrbmp.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
rdrle.obj: rdrle.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
wrrle.obj: wrrle.c cdjpeg.h jinclude.h jconfig.h jpeglib.h jmorecfg.h jerror.h cderror.h
